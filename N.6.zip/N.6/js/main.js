//bx slider//
 $(document).ready(function(){
    $('.slider_area').bxSlider();
    jQuery('#main_menu').meanmenu({
      meanMenuContainer:'#mobile_menu',
      meanScreenWidth:991,
    });
  });
